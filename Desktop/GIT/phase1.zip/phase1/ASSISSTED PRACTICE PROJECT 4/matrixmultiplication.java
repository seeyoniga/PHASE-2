import java.util.*;

public class matrixmultiplication{  
	
	public static void printmatA(int mat[][])
    {
        for (int[] row : mat)
            System.out.println(Arrays.toString(row));
    }
	public static void main(String args[]){      
		int a[][]={{1,2,3},{4,5,6},{7,8,9}};    
		int b[][]={{9,8,7},{6,5,4},{3,2,1}};       
		System.out.print(" Matrix A :\n"); 
		printmatA(a);
		System.out.print(" \n Matrix B :\n"); 
		printmatA(b);
		System.out.print(" \nProduct of Matrix A and B :\n");
		int c[][]=new int[3][3]; 
		for(int i=0;i<3;i++){    
			for(int j=0;j<3;j++){    
				c[i][j]=0;      
				for(int k=0;k<3;k++){      
					c[i][j]+=a[i][k]*b[k][j];      
				}  
				System.out.print(c[i][j]+" "); 
			}
			System.out.println();   
		}   
	}
}  