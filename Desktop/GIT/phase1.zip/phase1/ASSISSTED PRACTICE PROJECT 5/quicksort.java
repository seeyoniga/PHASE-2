import java.util.*;

public class quicksort {
	static int part(int ar[], int low, int high) {
		int pivot = ar[high];
    int i = (low - 1);
    for (int j = low; j < high; j++) {
      if (ar[j] <= pivot) {
        i++;
        int temp = ar[i];
        ar[i] = ar[j];
        ar[j] = temp;
      }

    }
    int temp = ar[i + 1];
    ar[i + 1] = ar[high];
    ar[high] = temp;
    return (i + 1);
  }

  static void sort(int ar[], int low, int high) {
    if (low < high) {
      int pi = part(ar, low, high);
      sort(ar, low, pi - 1);
      sort(ar, pi + 1, high);
    }
  }
  public static void main(String args[]) {

    int a[] = {35,12,9,21,3,54};
    System.out.println("Array before sorting");
    System.out.println(Arrays.toString(a));
    int s = a.length;
    quicksort.sort(a, 0, s-1);
    System.out.println("Array after sorting");
    System.out.println(Arrays.toString(a));
  }
}