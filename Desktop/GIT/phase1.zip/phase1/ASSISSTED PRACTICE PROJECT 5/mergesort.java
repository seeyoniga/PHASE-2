public class mergesort {  
void merge(int a[], int beg, int mid, int end)    
{    
    int i, j, k;  
    int n1 = mid-beg+1;    
    int n2 = end-mid;     
        int la[] = new int[n1];  
        int ra[] = new int[n2];   
    for (i = 0; i < n1; i++)    
    la[i] = a[beg + i];    
    for (j = 0; j < n2; j++)    
    ra[j] = a[mid + 1 + j];        
    i = 0; 
    j = 0;   
    k = beg;
      
    while (i < n1 && j < n2)    
    {    
        if(la[i] <= ra[j])    
        {    
            a[k] = la[i];    
            i++;    
        }    
        else    
        {    
            a[k] = ra[j];    
            j++;    
        }    
        k++;    
    }    
    while (i<n1)    
    {    
        a[k] = la[i];    
        i++;    
        k++;    
    }    
      
    while (j<n2)    
    {    
        a[k] = ra[j];    
        j++;    
        k++;    
    }    
}    
  
void sort(int a[], int beg, int end)  
{  
    if (beg < end)   
    {  
        int mid = (beg + end) / 2;  
        sort(a, beg, mid);  
        sort(a, mid + 1, end);  
        merge(a, beg, mid, end);  
    }  
}   
void printArray(int a[], int n)  
{  
    int i;  
    for (i = 0; i < n; i++)  
        System.out.print(a[i] + " ");  
}  
  
public static void main(String args[])  
{  
    int a[] = {35,12,9,21,3,54};  
    int n = a.length;  
    mergesort m = new mergesort();  
    System.out.println("Array before sorting");  
    m.printArray(a, n);  
    m.sort(a, 0, n - 1);  
    System.out.println("Array after sorting");  
    m.printArray(a, n);  
    System.out.println("");  
}  
  
  }  