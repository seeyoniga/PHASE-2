import java.util.*;
public class linearsearch{    
    public static void main(String [] args){ 
        Scanner sc = new Scanner(System.in);
        int result = -1;
        int a1[]= {1,2,3,4,5};
        System.out.println(" Enter the element to be searched :");
        int key = sc.nextInt();
        for(int i=0;i<a1.length;i++){    
            if(a1[i] == key){    
                result = i; 
                if (result>=0){
        }
                else{
                   result=-1;
        }
            } 
        } 
        if (result>=0){
        	System.out.println(key+" is found at index: "+result);
        }
        else{
        	
           System.out.println("Element not found in array");
        }
    }       
}  